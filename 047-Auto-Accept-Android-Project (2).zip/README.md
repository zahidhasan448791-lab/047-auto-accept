# 047 Auto Accept - Native Android Application

A high-performance, battery-friendly native Android helper for delivery drivers using **Al Sharouq Express**.

Automatically accepts **ONLY** orders belonging to store/branch code **047** when the "Accept the order" button is visible.

### How to Build APK
1. Open this folder in Android Studio.
2. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. Transfer `app-debug.apk` to your phone.
4. Open the app, click **"Open Accessibility Settings"**, enable **"047 Auto Accept"**, and turn **Automation ON**!
