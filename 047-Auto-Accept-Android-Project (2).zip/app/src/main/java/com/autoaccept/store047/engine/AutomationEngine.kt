package com.autoaccept.store047.engine

import android.view.accessibility.AccessibilityNodeInfo
import com.autoaccept.store047.data.LogLevel
import com.autoaccept.store047.data.LogRepository
import java.util.regex.Pattern

class AutomationEngine {
    companion object {
        const val TARGET_BUTTON_TEXT = "Accept the order"
        const val COOLDOWN_MILLIS = 3000L
        val FORBIDDEN_BUTTONS = listOf("Order picked up", "Order Details", "Cancel", "Reject", "Arrived")
    }

    private var lastAcceptedTimestamp: Long = 0L
    private var lastClickedNodeHash: Int = 0

    @Synchronized
    fun processWindow(rootNode: AccessibilityNodeInfo?, storeCode: String, targetPackage: String = "") {
        if (rootNode == null) return
        val now = System.currentTimeMillis()
        if (now - lastAcceptedTimestamp < COOLDOWN_MILLIS) return

        val storePattern = Pattern.compile("\\b" + Pattern.quote(storeCode.trim()) + "\\b", Pattern.CASE_INSENSITIVE)
        var storeMatched = false
        var acceptButtonNode: AccessibilityNodeInfo? = null

        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null || !node.isVisibleToUser) return
            val text = node.text?.toString()?.trim() ?: ""
            val desc = node.contentDescription?.toString()?.trim() ?: ""
            val item = if (text.isNotBlank()) text else desc

            if (item.isNotBlank()) {
                if (!storeMatched && storePattern.matcher(item).find()) {
                    storeMatched = true
                }
                if (acceptButtonNode == null && item.equals(TARGET_BUTTON_TEXT, ignoreCase = true)) {
                    acceptButtonNode = node
                }
            }

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }

        traverse(rootNode)

        if (!storeMatched) {
            if (acceptButtonNode != null) {
                LogRepository.addLog("Ignored: store code $storeCode not found", LogLevel.IGNORED)
            }
            return
        }

        LogRepository.addLog("$storeCode order detected", LogLevel.INFO)

        if (acceptButtonNode == null) {
            LogRepository.addLog("Ignored: Accept the order button not found", LogLevel.IGNORED)
            return
        }

        LogRepository.addLog("Accept the order button found", LogLevel.INFO)

        var current: AccessibilityNodeInfo? = acceptButtonNode
        var clicked = false
        while (current != null && !clicked) {
            if (current.isClickable) {
                clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        if (!clicked) {
            clicked = acceptButtonNode!!.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }

        if (clicked) {
            lastAcceptedTimestamp = System.currentTimeMillis()
            LogRepository.addLog("Order accepted automatically for store $storeCode", LogLevel.SUCCESS)
        }
    }
}
