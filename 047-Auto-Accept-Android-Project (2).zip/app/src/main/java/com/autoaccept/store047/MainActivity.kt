package com.autoaccept.store047

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.autoaccept.store047.data.LogEntry
import com.autoaccept.store047.data.LogLevel
import com.autoaccept.store047.data.LogRepository
import com.autoaccept.store047.data.PreferencesManager
import com.autoaccept.store047.service.AutoAcceptAccessibilityService

class MainActivity : ComponentActivity() {

    private lateinit var prefsManager: PreferencesManager
    private val isAccessibilityEnabledState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefsManager = PreferencesManager.getInstance(this)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Color(0xFF020617),
                    surface = Color(0xFF0F172A),
                    primary = Color(0xFF10B981)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF020617)
                ) {
                    val isAutomationEnabled by prefsManager.isAutomationEnabled.collectAsState()
                    val storeCode by prefsManager.storeCode.collectAsState()
                    val logs by LogRepository.logs.collectAsState()
                    val isServiceConnected by AutoAcceptAccessibilityService.isServiceConnected.collectAsState()

                    val isAccessibilityEnabled = isAccessibilityEnabledState.value || isServiceConnected

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF059669)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("047", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color.White)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "047 Auto Accept",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "Al Sharouq Express Delivery Assistant",
                                    fontSize = 12.sp,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isAccessibilityEnabled) Color(0xFF064E3B) else Color(0xFF7F1D1D)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = if (isAccessibilityEnabled) "Accessibility Service: ACTIVE" else "Accessibility Service: OFF",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (isAccessibilityEnabled) "Ready to monitor store orders." else "Tap below to enable in Android Settings.",
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 12.sp
                                )
                                if (!isAccessibilityEnabled) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Button(
                                        onClick = {
                                            try {
                                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                                })
                                            } catch (e: Exception) {
                                                LogRepository.addLog("Error opening settings: ${e.message}", LogLevel.WARNING)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White)
                                    ) {
                                        Text("Enable in Settings", color = Color(0xFF7F1D1D), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Auto-Accept Status",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = if (isAutomationEnabled) "Auto-accepting store $storeCode" else "Automation is paused",
                                        color = if (isAutomationEnabled) Color(0xFF34D399) else Color(0xFF94A3B8),
                                        fontSize = 12.sp
                                    )
                                }
                                Switch(
                                    checked = isAutomationEnabled,
                                    onCheckedChange = { enabled ->
                                        prefsManager.setAutomationEnabled(enabled)
                                        LogRepository.addLog(
                                            if (enabled) "Automation ON: Monitoring store $storeCode" else "Automation OFF",
                                            if (enabled) LogLevel.INFO else LogLevel.WARNING
                                        )
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF059669)
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Target Store Code", fontWeight = FontWeight.SemiBold, color = Color(0xFF94A3B8), fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = storeCode,
                                    onValueChange = { newCode ->
                                        prefsManager.setStoreCode(newCode)
                                        LogRepository.addLog("Store code changed to: $newCode", LogLevel.INFO)
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFF10B981),
                                        unfocusedBorderColor = Color(0xFF334155)
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        LogRepository.addLog("Self-Test: Store $storeCode detected", LogLevel.INFO)
                                        LogRepository.addLog("Self-Test: 'Accept the order' button found", LogLevel.INFO)
                                        LogRepository.addLog("Order accepted automatically for store $storeCode", LogLevel.SUCCESS)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Run Self-Test", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Activity Log", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            TextButton(onClick = { LogRepository.clearLogs() }) {
                                Text("Clear", color = Color(0xFF94A3B8), fontSize = 12.sp)
                            }
                        }

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0B1120))
                                .padding(8.dp)
                        ) {
                            items(logs) { entry ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "[${entry.timestamp}]",
                                        color = Color(0xFF64748B),
                                        fontSize = 11.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = entry.message,
                                        color = when (entry.level) {
                                            LogLevel.SUCCESS -> Color(0xFF34D399)
                                            LogLevel.WARNING -> Color(0xFFFBBF24)
                                            LogLevel.IGNORED -> Color(0xFF94A3B8)
                                            else -> Color(0xFFE2E8F0)
                                        },
                                        fontSize = 12.sp,
                                        fontWeight = if (entry.level == LogLevel.SUCCESS) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkAccessibilityStatus()
    }

    private fun checkAccessibilityStatus() {
        isAccessibilityEnabledState.value = isAccessibilityServiceEnabled(this)
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedServiceName = "${context.packageName}/${AutoAcceptAccessibilityService::class.java.canonicalName}"
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)

        for (service in enabledServices) {
            val resolveInfo = service.resolveInfo
            if (resolveInfo != null) {
                val serviceInfo = resolveInfo.serviceInfo
                val fullServiceName = "${serviceInfo.packageName}/${serviceInfo.name}"
                if (fullServiceName.equals(expectedServiceName, ignoreCase = true) ||
                    serviceInfo.packageName == context.packageName
                ) {
                    return true
                }
            }
        }
        return false
    }
}

