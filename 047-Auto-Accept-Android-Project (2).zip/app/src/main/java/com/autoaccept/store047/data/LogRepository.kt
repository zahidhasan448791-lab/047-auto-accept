package com.autoaccept.store047.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

enum class LogLevel { INFO, SUCCESS, WARNING, IGNORED }
data class LogEntry(val id: Long = System.currentTimeMillis() + (0..999).random(), val timestamp: String, val message: String, val level: LogLevel)

object LogRepository {
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val _logs = MutableStateFlow<List<LogEntry>>(listOf(
        LogEntry(timestamp = timeFormat.format(Date()), message = "047 Auto Accept initialized. Automation is OFF.", level = LogLevel.INFO)
    ))
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    @Synchronized
    fun addLog(msg: String, lvl: LogLevel = LogLevel.INFO) {
        val entry = LogEntry(timestamp = timeFormat.format(Date()), message = msg, level = lvl)
        val list = _logs.value.toMutableList()
        list.add(0, entry)
        _logs.value = list.take(150)
    }

    @Synchronized
    fun clearLogs() {
        _logs.value = emptyList()
    }
}
