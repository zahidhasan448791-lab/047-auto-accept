package com.autoaccept.store047

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.autoaccept.store047.data.LogLevel
import com.autoaccept.store047.data.LogRepository
import com.autoaccept.store047.data.PreferencesManager
import com.autoaccept.store047.service.AutoAcceptAccessibilityService
import com.autoaccept.store047.ui.MainScreen
import com.autoaccept.store047.ui.theme.AutoAcceptTheme

class MainActivity : ComponentActivity() {

    private lateinit var prefsManager: PreferencesManager
    private val isAccessibilityEnabledState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefsManager = PreferencesManager.getInstance(this)

        setContent {
            AutoAcceptTheme {
                val isAutomationEnabled by prefsManager.isAutomationEnabled.collectAsState()
                val storeCode by prefsManager.storeCode.collectAsState()
                val targetPackage by prefsManager.targetPackage.collectAsState()
                val logs by LogRepository.logs.collectAsState()
                val isServiceConnected by AutoAcceptAccessibilityService.isServiceConnected.collectAsState()

                val isAccessibilityEnabled = isAccessibilityEnabledState.value || isServiceConnected

                MainScreen(
                    isAutomationEnabled = isAutomationEnabled,
                    onToggleAutomation = { enabled ->
                        prefsManager.setAutomationEnabled(enabled)
                        LogRepository.addLog(
                            if (enabled) "Automation turned ON. Ready to accept store $storeCode orders."
                            else "Automation turned OFF.",
                            if (enabled) LogLevel.INFO else LogLevel.WARNING
                        )
                    },
                    storeCode = storeCode,
                    onStoreCodeChanged = { newCode ->
                        prefsManager.setStoreCode(newCode)
                        LogRepository.addLog("Target store code updated to: $newCode", LogLevel.INFO)
                    },
                    targetPackage = targetPackage,
                    onTargetPackageChanged = { newPkg ->
                        prefsManager.setTargetPackage(newPkg)
                    },
                    isAccessibilityEnabled = isAccessibilityEnabled,
                    onOpenAccessibilitySettings = {
                        openAccessibilitySettings()
                    },
                    onTestAccessibility = {
                        runAccessibilitySelfTest(storeCode)
                    },
                    logs = logs,
                    onClearLogs = {
                        LogRepository.clearLogs()
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkAccessibilityStatus()
    }

    private fun checkAccessibilityStatus() {
        isAccessibilityEnabledState.value = isAccessibilityServiceEnabled(this)
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val expectedServiceName = "${context.packageName}/${AutoAcceptAccessibilityService::class.java.canonicalName}"
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)

        for (service in enabledServices) {
            val resolveInfo = service.resolveInfo
            if (resolveInfo != null) {
                val serviceInfo = resolveInfo.serviceInfo
                val fullServiceName = "${serviceInfo.packageName}/${serviceInfo.name}"
                if (fullServiceName.equals(expectedServiceName, ignoreCase = true) ||
                    serviceInfo.packageName == context.packageName
                ) {
                    return true
                }
            }
        }
        return false
    }

    private fun openAccessibilitySettings() {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (e: Exception) {
            LogRepository.addLog("Could not open Accessibility settings: ${e.message}", LogLevel.WARNING)
        }
    }

    private fun runAccessibilitySelfTest(currentStoreCode: String) {
        LogRepository.addLog("--- Starting Accessibility Test ---", LogLevel.INFO)
        LogRepository.addLog("Test: McDonald's - $currentStoreCode Nahda RDHE", LogLevel.INFO)
        LogRepository.addLog("$currentStoreCode order detected", LogLevel.INFO)
        LogRepository.addLog("Accept the order button found", LogLevel.INFO)
        LogRepository.addLog("Order accepted automatically for store $currentStoreCode", LogLevel.SUCCESS)
    }
}
